﻿using FruitApplication.Models;
using Microsoft.EntityFrameworkCore;

namespace FruitApplication.Context
{
    public class FruitContext : DbContext
    {
        public  FruitContext(DbContextOptions<FruitContext> options):base(options)
        {

        }
        public DbSet<Fruit> Fruits { get; set; }
    
    }
}
