﻿using Microsoft.EntityFrameworkCore;
using Person_Crud_Application.Models;

namespace Person_Crud_Application.Context
{
    public class PersonContext:DbContext
    {
        public PersonContext(DbContextOptions<PersonContext> options):base(options)
        {

        }
       public DbSet<Person>Persons {  get; set; }  
    }
  
}
