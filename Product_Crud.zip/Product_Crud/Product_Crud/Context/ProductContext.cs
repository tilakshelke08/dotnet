﻿using Microsoft.EntityFrameworkCore;
using Product_Crud.Models;

namespace Product_Crud.Context
{
    public class ProductContext : DbContext
    {

        public ProductContext(DbContextOptions<ProductContext> options) : base(options)
        {

        }
        public DbSet<Product>products { get; set; }
    }
}
