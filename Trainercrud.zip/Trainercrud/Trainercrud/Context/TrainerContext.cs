﻿using Microsoft.EntityFrameworkCore;
using Trainercrud.Models;

namespace Trainercrud.Context
{
    public class TrainerContext :DbContext
    {
        public TrainerContext(DbContextOptions<TrainerContext> options) :base(options) 
        {
            
        }
        public DbSet<Trainer> trainers { get; set; }
    }
}
