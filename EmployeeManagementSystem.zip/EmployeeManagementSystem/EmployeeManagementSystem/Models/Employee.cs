﻿using System.Diagnostics.CodeAnalysis;

namespace EmployeeManagementSystem.Models
{
    public class Employee
    {
        
        public int EmployeeId { get; set; }
            
        public string EmployeeName { get; set; }
        
        public string MobileNo { get; set; }
            
        public String City { get; set; }
        
        public String Email { get; set; }
       
        public string Address { get; set; }
      
        public string DateOfBirth { get; set; }
    }
}
